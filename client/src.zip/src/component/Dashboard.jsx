import React from 'react';


export const Dashboard = () => {
    return(<div>
        <h2>DashBoard</h2>
    </div>);
};
